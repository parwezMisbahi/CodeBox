package com.codebox.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/** Runs the user's HTML / JS file in a plain WebView (no access to the app bridge). */
class PreviewActivity : AppCompatActivity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("path")
        if (path == null) {
            finish()
            return
        }
        val file = File(path)

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = true
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(v: WebView?, url: String?, msg: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@PreviewActivity)
                    .setMessage(msg)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(v: WebView?, url: String?, msg: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@PreviewActivity)
                    .setMessage(msg)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }
                    .show()
                return true
            }
        }

        if (file.extension.lowercase() == "js") {
            val base = Uri.fromFile(file.parentFile).toString().trimEnd('/') + "/"
            web.loadDataWithBaseURL(base, jsRunnerHtml(file.name), "text/html", "utf-8", null)
        } else {
            web.loadUrl(Uri.fromFile(file).toString())
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })
    }

    private fun jsRunnerHtml(fileName: String): String = """
<!doctype html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<body style="background:#111;color:#9f9;font:14px monospace;padding:12px">
<pre id="o" style="white-space:pre-wrap"></pre>
<script>
const o = document.getElementById('o');
['log','info','warn','error'].forEach(k => {
  const orig = console[k];
  console[k] = (...a) => {
    o.textContent += a.map(x => typeof x === 'object' ? JSON.stringify(x) : String(x)).join(' ') + '\n';
    orig.apply(console, a);
  };
});
window.onerror = (m, s, l) => { o.textContent += 'ERROR: ' + m + ' (line ' + l + ')\n'; };
</script>
<script src="$fileName"></script>
""".trimIndent()

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
