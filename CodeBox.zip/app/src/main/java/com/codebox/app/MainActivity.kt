package com.codebox.app

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    lateinit var web: WebView
    lateinit var store: ProjectStore
    var pendingExport: String? = null

    private val zipPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importZip(uri)
        }

    private val zipExporter =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            val project = pendingExport
            pendingExport = null
            if (uri != null && project != null) exportZip(project, uri)
        }

    fun launchZipPicker() {
        zipPicker.launch(
            arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
        )
    }

    fun launchZipExport(project: String) {
        zipExporter.launch("$project.zip")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStore(filesDir)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage?): Boolean = true
        }
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.handleBack ? window.handleBack() : false)") { r ->
                    if (r != "true") finish()
                }
            }
        })
    }

    private fun emit(type: String, payload: String) {
        val js = "window.onNative && window.onNative(${JSONObject.quote(type)}, ${JSONObject.quote(payload)})"
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    private fun displayName(uri: Uri): String {
        var name = "project"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
        }
        return name.removeSuffix(".zip").removeSuffix(".ZIP")
    }

    private fun importZip(uri: Uri) {
        val base = displayName(uri)
        thread {
            try {
                val input = contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("Zip khul nahi saki")
                val name = store.unzip(input, base)
                emit("imported", name)
            } catch (t: Throwable) {
                emit("error", "Import fail: " + (t.message ?: t.toString()))
            }
        }
    }

    private fun exportZip(project: String, uri: Uri) {
        thread {
            try {
                val out = contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("Save location nahi khuli")
                store.zipProject(project, out)
                emit("exported", project)
            } catch (t: Throwable) {
                emit("error", "Export fail: " + (t.message ?: t.toString()))
            }
        }
    }
}
