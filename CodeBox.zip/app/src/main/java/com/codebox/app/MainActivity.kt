package com.codebox.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    lateinit var web: WebView
    lateinit var store: ProjectStore
    var pendingExport: String? = null
    private var lastApk: File? = null
    private val building = AtomicBoolean(false)

    fun prefs(): SharedPreferences = getSharedPreferences("codebox", Context.MODE_PRIVATE)

    private val zipPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importZip(uri)
        }

    private val zipExporter =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            val project = pendingExport
            pendingExport = null
            if (uri != null && project != null) exportZip(project, uri)
        }

    fun launchZipPicker() {
        zipPicker.launch(
            arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
        )
    }

    fun launchZipExport(project: String) {
        zipExporter.launch("$project.zip")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStore(filesDir)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage?): Boolean = true
        }
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.handleBack ? window.handleBack() : false)") { r ->
                    if (r != "true") finish()
                }
            }
        })
    }

    fun emit(type: String, payload: String) {
        val js = "window.onNative && window.onNative(${JSONObject.quote(type)}, ${JSONObject.quote(payload)})"
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    private fun displayName(uri: Uri): String {
        var name = "project"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
        }
        return name.removeSuffix(".zip").removeSuffix(".ZIP")
    }

    private fun importZip(uri: Uri) {
        val base = displayName(uri)
        thread {
            try {
                val input = contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("Zip khul nahi saki")
                val name = store.unzip(input, base)
                emit("imported", name)
            } catch (t: Throwable) {
                emit("error", "Import fail: " + (t.message ?: t.toString()))
            }
        }
    }

    private fun exportZip(project: String, uri: Uri) {
        thread {
            try {
                val out = contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("Save location nahi khuli")
                store.zipProject(project, out)
                emit("exported", project)
            } catch (t: Throwable) {
                emit("error", "Export fail: " + (t.message ?: t.toString()))
            }
        }
    }

    /* ---------- cloud build (GitHub Actions) ---------- */

    private fun buildEvent(stage: String, vararg extra: Pair<String, String>) {
        val o = JSONObject().put("stage", stage)
        extra.forEach { o.put(it.first, it.second) }
        emit("build", o.toString())
    }

    fun startBuild(project: String) {
        val token = prefs().getString("gh_token", null)
        if (token.isNullOrEmpty()) throw IllegalStateException("GitHub token set nahi hai")
        if (!building.compareAndSet(false, true)) throw IllegalStateException("Build pehle se chal raha hai")
        thread {
            try {
                buildEvent("progress", "msg" to "Project zip ban rahi hai...")
                val zip = File(cacheDir, "project.zip")
                zip.outputStream().use { store.zipProject(project, it, forBuild = true) }
                val workflow = assets.open("cloud-build.yml").use { it.readBytes() }
                val builder = CloudBuild(token, cacheDir, workflow) { m ->
                    buildEvent("progress", "msg" to m)
                }
                val res = builder.run(zip, project)
                zip.delete()
                val apk = res.apk
                if (apk != null) {
                    lastApk = apk
                    buildEvent("done", "name" to apk.name)
                } else {
                    buildEvent("fail", "msg" to res.message, "log" to res.log)
                }
            } catch (t: Throwable) {
                buildEvent("fail", "msg" to (t.message ?: t.toString()), "log" to "")
            } finally {
                building.set(false)
            }
        }
    }

    fun installApk() {
        val apk = lastApk
        if (apk == null || !apk.exists()) {
            emit("error", "Pehle build karo, APK nahi mili")
            return
        }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            emit("error", "CodeBox ko install allow karo, phir Install dobara dabao")
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
        startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
