package com.codebox.app

import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class BuildResult(val apk: File?, val message: String, val log: String = "")

/**
 * Builds a project zip on GitHub Actions:
 * private repo <user>/codebox-builds -> upload project.zip -> dispatch workflow -> poll -> download APK.
 * Needs a GitHub token with scopes: repo + workflow.
 */
class CloudBuild(
    private val token: String,
    private val cacheDir: File,
    private val workflow: ByteArray,
    private val progress: (String) -> Unit
) {
    private class Resp(val code: Int, val text: String)

    private fun open(url: String, method: String, auth: Boolean): HttpURLConnection {
        val full = if (url.startsWith("http")) url else "https://api.github.com$url"
        val c = URL(full).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.instanceFollowRedirects = !auth
        c.connectTimeout = 20_000
        c.readTimeout = 180_000
        if (auth) {
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        }
        c.setRequestProperty("User-Agent", "CodeBox")
        return c
    }

    private fun req(method: String, url: String, body: String? = null): Resp {
        val c = open(url, method, true)
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val stream = if (code < 400) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        return Resp(code, text)
    }

    /** GitHub answers artifact/log downloads with a redirect to a signed URL, which must be fetched WITHOUT the token. */
    private fun download(url: String, dest: File) {
        val first = open(url, "GET", true)
        val code = first.responseCode
        val conn: HttpURLConnection = when {
            code in 300..399 -> {
                val loc = first.getHeaderField("Location")
                    ?: throw IllegalStateException("Download link nahi mila")
                first.disconnect()
                open(loc, "GET", false)
            }
            code == 200 -> first
            else -> throw IllegalStateException("Download fail ($code)")
        }
        if (conn.responseCode != 200) throw IllegalStateException("Download fail (${conn.responseCode})")
        conn.inputStream.use { i -> FileOutputStream(dest).use { i.copyTo(it) } }
        conn.disconnect()
    }

    private fun msg(r: Resp): String = try {
        JSONObject(r.text).optString("message", r.text.take(200))
    } catch (e: Exception) {
        "HTTP ${r.code}"
    }

    private fun fail(what: String, r: Resp): Nothing {
        val m = msg(r)
        val hint = when {
            m.contains("workflow", true) && m.contains("scope", true) -> " -> token me 'workflow' scope on karo"
            r.code == 401 -> " -> token galat ya expire ho gaya"
            r.code == 403 || r.code == 404 -> " -> token ke scopes (repo + workflow) check karo"
            else -> ""
        }
        throw IllegalStateException("$what: $m$hint")
    }

    private fun putFile(repo: String, branch: String, path: String, bytes: ByteArray, message: String, skipIfSame: Boolean) {
        val get = req("GET", "/repos/$repo/contents/$path?ref=$branch")
        var sha: String? = null
        if (get.code == 200) {
            val j = JSONObject(get.text)
            sha = j.optString("sha").ifEmpty { null }
            if (skipIfSame) {
                val old = Base64.decode(j.optString("content"), Base64.DEFAULT)
                if (old.contentEquals(bytes)) return
            }
        }
        val body = JSONObject()
            .put("message", message)
            .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
            .put("branch", branch)
        if (sha != null) body.put("sha", sha)
        var put = req("PUT", "/repos/$repo/contents/$path", body.toString())
        if (put.code == 409) { // branch moved while we uploaded - retry once
            Thread.sleep(2000)
            put = req("PUT", "/repos/$repo/contents/$path", body.toString())
        }
        if (put.code !in 200..201) fail("Upload fail ($path)", put)
    }

    private fun latestRunId(repo: String): Long {
        val r = req("GET", "/repos/$repo/actions/workflows/build.yml/runs?per_page=1")
        if (r.code != 200) return 0
        val a = JSONObject(r.text).optJSONArray("workflow_runs")
        return if (a != null && a.length() > 0) a.getJSONObject(0).getLong("id") else 0
    }

    fun run(zip: File, project: String): BuildResult {
        if (zip.length() > 30_000_000) throw IllegalStateException("Project zip 30MB se badi hai")

        progress("GitHub account check...")
        val me = req("GET", "/user")
        if (me.code != 200) fail("GitHub login fail", me)
        val login = JSONObject(me.text).getString("login")
        val repo = "$login/codebox-builds"

        progress("Repo check...")
        var r = req("GET", "/repos/$repo")
        if (r.code == 404) {
            progress("Private repo bana raha hoon (codebox-builds)...")
            r = req(
                "POST", "/user/repos",
                JSONObject().put("name", "codebox-builds").put("private", true)
                    .put("auto_init", true).put("description", "CodeBox cloud builds").toString()
            )
            if (r.code !in 200..299) fail("Repo nahi ban saki", r)
            Thread.sleep(3000)
        } else if (r.code != 200) {
            fail("Repo check fail", r)
        }
        val branch = JSONObject(r.text).optString("default_branch", "main")

        progress("Build workflow set kar raha hoon...")
        putFile(repo, branch, ".github/workflows/build.yml", workflow, "CodeBox: workflow", true)

        progress("Project upload ho raha hai (${zip.length() / 1024} KB)...")
        putFile(repo, branch, "project.zip", zip.readBytes(), "CodeBox: $project", false)

        progress("Build shuru kar raha hoon...")
        val prev = latestRunId(repo)
        var dispatched = false
        for (i in 1..8) {
            val d = req(
                "POST", "/repos/$repo/actions/workflows/build.yml/dispatches",
                JSONObject().put("ref", branch).toString()
            )
            if (d.code == 204) { dispatched = true; break }
            if (d.code == 404 || d.code == 422) { Thread.sleep(5000); continue }
            fail("Build trigger fail", d)
        }
        if (!dispatched) throw IllegalStateException("Workflow trigger nahi hua. Token me 'workflow' scope check karo.")

        var runId = 0L
        for (i in 1..25) {
            Thread.sleep(3000)
            val list = req("GET", "/repos/$repo/actions/workflows/build.yml/runs?per_page=5")
            if (list.code != 200) continue
            val arr = JSONObject(list.text).optJSONArray("workflow_runs") ?: continue
            for (k in 0 until arr.length()) {
                val id = arr.getJSONObject(k).getLong("id")
                if (id > prev && id > runId) runId = id
            }
            if (runId > 0) break
        }
        if (runId == 0L) throw IllegalStateException("Build run start nahi hua. GitHub Actions repo me enabled hai?")

        val t0 = System.currentTimeMillis()
        var conclusion = ""
        while (true) {
            Thread.sleep(8000)
            val elapsed = (System.currentTimeMillis() - t0) / 1000
            val st = req("GET", "/repos/$repo/actions/runs/$runId")
            if (st.code == 200) {
                val j = JSONObject(st.text)
                val status = j.getString("status")
                val label = if (status == "queued") "Queue me hai" else "Build chal raha hai"
                progress("$label (${elapsed / 60}m ${elapsed % 60}s)")
                if (status == "completed") {
                    conclusion = j.optString("conclusion")
                    break
                }
            }
            if (elapsed > 45 * 60) throw IllegalStateException("Build 45 minute se zyada chal raha hai, ruk gaya")
        }

        if (conclusion != "success") {
            val log = try { fetchLog(repo, runId) } catch (t: Throwable) { "" }
            return BuildResult(null, "Build fail hua ($conclusion)", log)
        }

        progress("APK download ho raha hai...")
        var art: JSONObject? = null
        for (i in 1..5) {
            val a = req("GET", "/repos/$repo/actions/runs/$runId/artifacts")
            if (a.code == 200) {
                val arr = JSONObject(a.text).optJSONArray("artifacts")
                if (arr != null && arr.length() > 0) { art = arr.getJSONObject(0); break }
            }
            Thread.sleep(3000)
        }
        if (art == null) return BuildResult(null, "Build pass hua par APK artifact nahi mila")

        val artZip = File(cacheDir, "artifact.zip")
        download(art.getString("archive_download_url"), artZip)
        val outDir = File(cacheDir, "apk").apply { deleteRecursively(); mkdirs() }
        var apk: File? = null
        ZipInputStream(FileInputStream(artZip)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory && e.name.endsWith(".apk") && apk == null) {
                    val f = File(outDir, "$project.apk")
                    FileOutputStream(f).use { z.copyTo(it) }
                    apk = f
                }
                z.closeEntry()
                e = z.nextEntry
            }
        }
        artZip.delete()
        val result = apk
        return if (result != null) BuildResult(result, "ok")
        else BuildResult(null, "Artifact me APK file nahi mili")
    }

    /** Pulls the useful part of the failed job log: Kotlin "e:" errors plus the last lines of the build step. */
    private fun fetchLog(repo: String, runId: Long): String {
        val f = File(cacheDir, "logs.zip")
        download("/repos/$repo/actions/runs/$runId/logs", f)
        var best: String? = null
        val all = StringBuilder()
        ZipInputStream(FileInputStream(f)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory && e.name.endsWith(".txt")) {
                    val txt = z.readBytes().toString(Charsets.UTF_8)
                    if (e.name.contains("Build debug APK")) best = txt
                    all.append(txt).append('\n')
                }
                z.closeEntry()
                e = z.nextEntry
            }
        }
        f.delete()
        val stamp = Regex("^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z ")
        val src = (best ?: all.toString()).lines().map { it.replace(stamp, "") }
        val errs = src.filter { it.startsWith("e: ") || it.contains("error:") }.distinct().take(30)
        val tail = src.takeLast(60)
        return (if (errs.isNotEmpty()) errs.joinToString("\n") + "\n-----\n" else "") + tail.joinToString("\n")
    }
}
