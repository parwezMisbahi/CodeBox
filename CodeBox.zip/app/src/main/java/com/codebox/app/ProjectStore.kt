package com.codebox.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** All projects live in <filesDir>/projects/<name>/ . Every path from JS is checked to stay inside. */
class ProjectStore(filesDir: File) {
    val root: File = File(filesDir, "projects").apply { mkdirs() }
    private val rootPath = root.canonicalPath

    fun resolve(rel: String): File {
        val f = File(root, rel).canonicalFile
        if (f.path != rootPath && !f.path.startsWith(rootPath + File.separator)) {
            throw SecurityException("Invalid path")
        }
        return f
    }

    fun projects(): JSONArray {
        val arr = JSONArray()
        root.listFiles()?.filter { it.isDirectory }
            ?.sortedBy { it.name.lowercase() }
            ?.forEach { arr.put(it.name) }
        return arr
    }

    fun list(rel: String): JSONArray {
        val arr = JSONArray()
        resolve(rel).listFiles()
            ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
            ?.forEach { arr.put(JSONObject().put("name", it.name).put("dir", it.isDirectory)) }
        return arr
    }

    fun uniqueName(base: String): String {
        val clean = base.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().ifEmpty { "project" }
        var name = clean
        var i = 2
        while (File(root, name).exists()) {
            name = "$clean-$i"
            i++
        }
        return name
    }

    fun readText(rel: String): String {
        val f = resolve(rel)
        if (!f.isFile) throw IllegalArgumentException("File nahi mili")
        if (f.length() > 2_000_000) throw IllegalArgumentException("File bahut badi hai (2MB se zyada)")
        val bytes = f.readBytes()
        val probe = minOf(bytes.size, 8000)
        for (i in 0 until probe) {
            if (bytes[i].toInt() == 0) throw IllegalArgumentException("Binary file hai, editor me nahi khulegi")
        }
        return String(bytes, Charsets.UTF_8)
    }

    fun writeText(rel: String, text: String) {
        val f = resolve(rel)
        f.parentFile?.mkdirs()
        f.writeText(text, Charsets.UTF_8)
    }

    fun createFile(rel: String) {
        val f = resolve(rel)
        if (f.exists()) throw IllegalArgumentException("Pehle se maujood hai")
        f.parentFile?.mkdirs()
        f.createNewFile()
    }

    fun createDir(rel: String) {
        val f = resolve(rel)
        if (f.exists()) throw IllegalArgumentException("Pehle se maujood hai")
        f.mkdirs()
    }

    fun remove(rel: String) {
        val f = resolve(rel)
        if (f.path == rootPath) throw SecurityException("Invalid path")
        f.deleteRecursively()
    }

    fun rename(rel: String, newRel: String) {
        val from = resolve(rel)
        val to = resolve(newRel)
        if (to.exists()) throw IllegalArgumentException("Is naam se pehle se kuch hai")
        to.parentFile?.mkdirs()
        if (!from.renameTo(to)) throw IllegalStateException("Rename fail ho gaya")
    }

    fun createProject(name: String): String {
        val n = uniqueName(name)
        val dir = File(root, n).apply { mkdirs() }
        File(dir, "index.html").writeText(
            """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>$n</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>Hello, $n!</h1>
  <button id="btn">Click me</button>
  <script src="script.js"></script>
</body>
</html>
"""
        )
        File(dir, "style.css").writeText(
            "body {\n  font-family: sans-serif;\n  padding: 24px;\n}\n"
        )
        File(dir, "script.js").writeText(
            "document.getElementById('btn').addEventListener('click', () => {\n  alert('It works!');\n});\n"
        )
        return n
    }

    /** Extracts a zip into a new project folder. Protects against zip-slip. */
    fun unzip(input: InputStream, baseName: String): String {
        val name = uniqueName(baseName)
        val dest = File(root, name).apply { mkdirs() }
        val destPath = dest.canonicalPath
        try {
            ZipInputStream(BufferedInputStream(input)).use { zin ->
                var e: ZipEntry? = zin.nextEntry
                while (e != null) {
                    val entryName = e.name
                    val skip = entryName.startsWith("__MACOSX") || entryName.endsWith(".DS_Store")
                    val out = File(dest, entryName).canonicalFile
                    if (!skip && out.path.startsWith(destPath + File.separator)) {
                        if (e.isDirectory) {
                            out.mkdirs()
                        } else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { zin.copyTo(it) }
                        }
                    }
                    zin.closeEntry()
                    e = zin.nextEntry
                }
            }
            flattenSingleRoot(dest)
        } catch (t: Throwable) {
            dest.deleteRecursively()
            throw t
        }
        return name
    }

    /** If the zip had one top-level folder (project/...), move its content up one level. */
    private fun flattenSingleRoot(dest: File) {
        val children = dest.listFiles() ?: return
        if (children.size != 1 || !children[0].isDirectory) return
        val tmp = File(dest, ".__flatten_tmp")
        if (!children[0].renameTo(tmp)) return
        tmp.listFiles()?.forEach { it.renameTo(File(dest, it.name)) }
        tmp.deleteRecursively()
    }

    fun zipProject(name: String, out: OutputStream) {
        val dir = resolve(name)
        if (!dir.isDirectory) throw IllegalArgumentException("Project nahi mila")
        ZipOutputStream(out).use { zos ->
            dir.walkTopDown().filter { it.isFile }.forEach { f ->
                val rel = f.relativeTo(dir).path.replace(File.separatorChar, '/')
                zos.putNextEntry(ZipEntry(rel))
                FileInputStream(f).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }
}
