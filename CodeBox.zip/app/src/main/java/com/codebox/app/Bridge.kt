package com.codebox.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface
import android.widget.Toast
import org.json.JSONObject

/** Exposed to the editor UI as `window.Android`. Every method returns {"ok":bool,"data":...,"error":"..."}. */
class Bridge(private val a: MainActivity) {

    private fun ok(v: Any? = true): String = JSONObject().put("ok", true).put("data", v).toString()
    private fun err(e: Throwable): String =
        JSONObject().put("ok", false).put("error", e.message ?: e.toString()).toString()

    private inline fun safe(f: () -> Any?): String = try {
        ok(f())
    } catch (e: Throwable) {
        err(e)
    }

    @JavascriptInterface
    fun projects(): String = safe { a.store.projects() }

    @JavascriptInterface
    fun list(rel: String): String = safe { a.store.list(rel) }

    @JavascriptInterface
    fun read(rel: String): String = safe { a.store.readText(rel) }

    @JavascriptInterface
    fun write(rel: String, text: String): String = safe { a.store.writeText(rel, text); true }

    @JavascriptInterface
    fun createFile(rel: String): String = safe { a.store.createFile(rel); true }

    @JavascriptInterface
    fun createDir(rel: String): String = safe { a.store.createDir(rel); true }

    @JavascriptInterface
    fun remove(rel: String): String = safe { a.store.remove(rel); true }

    @JavascriptInterface
    fun rename(rel: String, newRel: String): String = safe { a.store.rename(rel, newRel); true }

    @JavascriptInterface
    fun createProject(name: String): String = safe { a.store.createProject(name) }

    @JavascriptInterface
    fun importZip(): String = safe {
        a.runOnUiThread { a.launchZipPicker() }
        true
    }

    @JavascriptInterface
    fun importFiles(dirRel: String): String = safe {
        a.store.resolve(dirRel) // validate
        a.runOnUiThread { a.launchFilesPicker(dirRel) }
        true
    }

    @JavascriptInterface
    fun importFolder(): String = safe {
        a.runOnUiThread { a.launchFolderPicker() }
        true
    }

    @JavascriptInterface
    fun exportZip(project: String): String = safe {
        a.store.resolve(project) // validate
        a.pendingExport = project
        a.runOnUiThread { a.launchZipExport(project) }
        true
    }

    @JavascriptInterface
    fun preview(rel: String): String = safe {
        val f = a.store.resolve(rel)
        if (!f.isFile) throw IllegalArgumentException("File nahi mili")
        val project = rel.substringBefore('/')
        val mocks = if (a.store.isAndroidProject(project)) a.store.bridgeNames(project).toString() else "[]"
        a.runOnUiThread {
            a.startActivity(
                Intent(a, PreviewActivity::class.java)
                    .putExtra("path", f.path)
                    .putExtra("mocks", mocks)
            )
        }
        true
    }

    @JavascriptInterface
    fun webEntry(project: String): String = safe {
        JSONObject().put("entry", a.store.webEntry(project) ?: JSONObject.NULL)
    }

    @JavascriptInterface
    fun toast(msg: String) {
        a.runOnUiThread { Toast.makeText(a, msg, Toast.LENGTH_SHORT).show() }
    }

    /* ---------- GitHub cloud build ---------- */

    @JavascriptInterface
    fun hasToken(): String = safe { !a.prefs().getString("gh_token", null).isNullOrEmpty() }

    @JavascriptInterface
    fun setToken(t: String): String = safe {
        val v = t.trim()
        require(v.matches(Regex("[A-Za-z0-9_\\-]{20,}"))) { "Token ka format galat lagta hai" }
        a.prefs().edit().putString("gh_token", v).apply()
        true
    }

    @JavascriptInterface
    fun clearToken(): String = safe { a.prefs().edit().remove("gh_token").apply(); true }

    @JavascriptInterface
    fun build(project: String): String = safe {
        a.store.resolve(project) // validate
        a.startBuild(project)
        true
    }

    @JavascriptInterface
    fun installApk(): String = safe { a.runOnUiThread { a.installApk() }; true }

    @JavascriptInterface
    fun openUrl(url: String): String = safe {
        require(url.startsWith("https://github.com/")) { "Sirf github.com links allowed hain" }
        a.runOnUiThread { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        true
    }

    @JavascriptInterface
    fun copy(text: String): String = safe {
        a.runOnUiThread {
            val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", text))
        }
        true
    }
}
