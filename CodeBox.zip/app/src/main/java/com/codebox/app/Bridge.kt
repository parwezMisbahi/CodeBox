package com.codebox.app

import android.content.Intent
import android.webkit.JavascriptInterface
import android.widget.Toast
import org.json.JSONObject

/** Exposed to the editor UI as `window.Android`. Every method returns {"ok":bool,"data":...,"error":"..."}. */
class Bridge(private val a: MainActivity) {

    private fun ok(v: Any? = true): String = JSONObject().put("ok", true).put("data", v).toString()
    private fun err(e: Throwable): String =
        JSONObject().put("ok", false).put("error", e.message ?: e.toString()).toString()

    private inline fun safe(f: () -> Any?): String = try {
        ok(f())
    } catch (e: Throwable) {
        err(e)
    }

    @JavascriptInterface
    fun projects(): String = safe { a.store.projects() }

    @JavascriptInterface
    fun list(rel: String): String = safe { a.store.list(rel) }

    @JavascriptInterface
    fun read(rel: String): String = safe { a.store.readText(rel) }

    @JavascriptInterface
    fun write(rel: String, text: String): String = safe { a.store.writeText(rel, text); true }

    @JavascriptInterface
    fun createFile(rel: String): String = safe { a.store.createFile(rel); true }

    @JavascriptInterface
    fun createDir(rel: String): String = safe { a.store.createDir(rel); true }

    @JavascriptInterface
    fun remove(rel: String): String = safe { a.store.remove(rel); true }

    @JavascriptInterface
    fun rename(rel: String, newRel: String): String = safe { a.store.rename(rel, newRel); true }

    @JavascriptInterface
    fun createProject(name: String): String = safe { a.store.createProject(name) }

    @JavascriptInterface
    fun importZip(): String = safe {
        a.runOnUiThread { a.launchZipPicker() }
        true
    }

    @JavascriptInterface
    fun exportZip(project: String): String = safe {
        a.store.resolve(project) // validate
        a.pendingExport = project
        a.runOnUiThread { a.launchZipExport(project) }
        true
    }

    @JavascriptInterface
    fun preview(rel: String): String = safe {
        val f = a.store.resolve(rel)
        if (!f.isFile) throw IllegalArgumentException("File nahi mili")
        a.runOnUiThread {
            a.startActivity(Intent(a, PreviewActivity::class.java).putExtra("path", f.path))
        }
        true
    }

    @JavascriptInterface
    fun toast(msg: String) {
        a.runOnUiThread { Toast.makeText(a, msg, Toast.LENGTH_SHORT).show() }
    }
}
