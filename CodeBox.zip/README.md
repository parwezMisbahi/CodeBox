# CodeBox

Spck jaisa chhota Android code editor: zip import, file tree, syntax-highlight editor, HTML/JS run, zip export.

## Kya kya hai
- **Import zip**: zip ko `files/projects/<naam>/` me extract karta hai (zip-slip safe, single root folder auto-flatten).
- **File tree**: new file/folder, rename, delete.
- **Editor**: CodeMirror 5 (HTML, CSS, JS, TS, Kotlin, Java, Python, C/C++, Go, Rust, PHP, MD, YAML ... ke modes).
- **Run**: `.html` WebView preview me, `.js` console-output ke saath. Kotlin/Java jaisi compiled languages phone par run nahi hoti.
- **Export zip**: project ko wapas zip kar ke save karta hai.

## Build (GitHub Actions)
1. Is folder ko GitHub repo me push karo (branch `main`).
2. Actions tab -> "Build APK" chalega (ya "Run workflow").
3. Artifact `CodeBox-debug-apk` se `app-debug.apk` download karo.

Local build: Android Studio me folder kholo, ya `gradle assembleDebug` (JDK 17 + Android SDK chahiye).

## Offline editor
Editor files pehli baar CDN (jsDelivr) se aati hain, phir WebView cache kar leta hai.
Poora offline chahiye to `codemirror@5.65.16` npm package se ye folders
`app/src/main/assets/cm/` me copy karo (same structure):

    lib/codemirror.js  lib/codemirror.css  theme/material-darker.css
    mode/meta.js  mode/<xml,javascript,css,htmlmixed,clike,python,markdown,shell,sql,yaml,go,rust,groovy,toml,properties,ruby,swift,php>/
    addon/edit/closebrackets.js  addon/edit/matchbrackets.js  addon/selection/active-line.js

App pehle `cm/` se load karta hai, na mile to CDN.

## Cloud build (Kotlin/Java/Android projects)
Drawer me **Build APK**: project zip hoke tumhari private repo `<user>/codebox-builds` me jati hai, GitHub Actions build karta hai, APK app me download hoke Install button aata hai. Fail hone par error log app me dikhta aur copy hota hai.
Pehli baar GitHub token (scopes: `repo`, `workflow`) paste karna padta hai; wo sirf app ke private storage me rehta hai.
Note: GitHub runner har build par nayi debug key banata hai, isliye purani build ke upar update install na ho to pehle purani app uninstall karo.

## Aage ke steps
- Termux-style local runtime (proot) bhi possible hai, par app bahut bhari hoti hai.
