(function () {
  var MOCKS = __MOCKS__;
  var logs = [];
  var panel = null, list = null, badge = null, title = null;

  function short(v) {
    try {
      var s = typeof v === 'string' ? v : JSON.stringify(v);
      if (s === undefined) s = String(v);
      return s.length > 90 ? s.slice(0, 90) + '…' : s;
    } catch (e) { return String(v); }
  }

  function errCount() {
    var n = 0;
    for (var i = 0; i < logs.length; i++) if (logs[i].k === 'err') n++;
    return n;
  }

  function draw() {
    if (!list) return;
    list.textContent = '';
    var colors = { err: '#ff6b6b', warn: '#ffb74d', native: '#4fc3f7', log: '#ddd' };
    logs.forEach(function (l) {
      var d = document.createElement('div');
      d.style.cssText = 'padding:2px 0;border-bottom:1px solid #222;word-break:break-all;color:' + (colors[l.k] || '#ddd');
      d.textContent = (l.k === 'native' ? '⇢ ' : l.k === 'err' ? '✗ ' : '') + l.t;
      list.appendChild(d);
    });
    list.scrollTop = list.scrollHeight;
  }

  function add(kind, text) {
    logs.push({ k: kind, t: text });
    if (logs.length > 300) logs.shift();
    if (badge) { var n = errCount(); badge.textContent = n ? '🐞 ' + n : '🐞'; }
    if (panel && panel.style.display !== 'none') draw();
  }

  ['log', 'info', 'warn', 'error'].forEach(function (k) {
    var orig = console[k];
    console[k] = function () {
      var a = [].slice.call(arguments).map(short).join(' ');
      add(k === 'error' ? 'err' : k === 'warn' ? 'warn' : 'log', a);
      try { orig.apply(console, arguments); } catch (e) {}
    };
  });
  window.addEventListener('error', function (e) {
    add('err', (e.message || 'error') + (e.filename ? ' (' + e.filename.split('/').pop() + ':' + e.lineno + ')' : ''));
  });
  window.addEventListener('unhandledrejection', function (e) {
    add('err', 'Promise: ' + short((e.reason && e.reason.message) || e.reason));
  });

  // Guess a harmless return value for a native call (real bridge methods usually return strings / JSON).
  function mockReturn(name) {
    if (/^(is|has|can|should|was)[A-Z_]/.test(name)) return 'false';
    if (/^(get|list|load|read|fetch|query)\w*(s|List|All)$/.test(name)) return '[]';
    if (/^(get|load|read|fetch|query)/.test(name)) return '{}';
    return '';
  }

  MOCKS.forEach(function (name) {
    if (window[name]) return;
    window[name] = new Proxy({}, {
      get: function (t, p) {
        if (typeof p !== 'string') return undefined;
        return function () {
          var args = [].slice.call(arguments);
          add('native', name + '.' + p + '(' + args.map(short).join(', ') + ')');
          return mockReturn(p);
        };
      }
    });
  });


  // Inside the phone simulator (page is an iframe): PhoneSim API talks to the fake phone.
  if (window.parent !== window) {
    var rid = 0, pend = {}, lst = {};
    var send = function (cmd) {
      var args = [].slice.call(arguments, 1);
      return new Promise(function (res) {
        var id = ++rid; pend[id] = res;
        parent.postMessage({ __phone: 1, cmd: cmd, args: args, rid: id }, '*');
      });
    };
    window.addEventListener('message', function (e) {
      var d = e.data || {};
      if (d.__phoneReply) { var f = pend[d.rid]; if (f) { delete pend[d.rid]; f(d.value); } }
      else if (d.__phoneLog) add('native', d.text);
      else if (d.__phoneEvt) {
        (lst[d.type] || []).forEach(function (fn) { try { fn(d.data); } catch (x) { add('err', String(x)); } });
        window.dispatchEvent(new CustomEvent('phone-' + d.type, { detail: d.data }));
      }
    });
    window.PhoneSim = {
      notify: function (n) { return send('notify', n); },
      cancelNotification: function (id) { return send('cancelNotification', id); },
      overlay: function (o) { return send('overlay', o); },
      removeOverlay: function (id) { return send('removeOverlay', id); },
      requestPermission: function (name) { return send('requestPermission', name); },
      toast: function (m) { return send('toast', m); },
      vibrate: function (ms) { return send('vibrate', ms); },
      goHome: function () { return send('home'); },
      a11y: {
        tap: function (x, y) { return send('a11yTap', x, y); },
        click: function (q) { return send('a11yClick', q); },
        tree: function () { return send('a11yTree'); }
      },
      on: function (type, fn) { (lst[type] = lst[type] || []).push(fn); }
    };
  }

  function btn(label, fn) {
    var b = document.createElement('button');
    b.textContent = label;
    b.style.cssText = 'background:#333;color:#fff;border:0;border-radius:6px;padding:6px 10px;font:12px sans-serif;margin-left:6px';
    b.addEventListener('click', fn);
    return b;
  }

  function build() {
    badge = document.createElement('button');
    badge.textContent = '🐞';
    badge.style.cssText = 'position:fixed;right:8px;bottom:8px;z-index:2147483647;background:rgba(0,0,0,.8);color:#fff;border:1px solid #555;border-radius:20px;padding:8px 12px;font:13px sans-serif';
    panel = document.createElement('div');
    panel.style.cssText = 'position:fixed;left:0;right:0;bottom:0;height:45%;background:#111;color:#ddd;z-index:2147483646;display:none;flex-direction:column;font:11px monospace;border-top:1px solid #444';
    var head = document.createElement('div');
    head.style.cssText = 'display:flex;align-items:center;padding:6px 8px;background:#1b1b1b';
    title = document.createElement('div');
    title.style.cssText = 'flex:1;font:12px sans-serif;color:#aaa';
    title.textContent = 'Dev log' + (MOCKS.length ? ' · mock bridge: ' + MOCKS.join(', ') : '');
    head.appendChild(title);
    head.appendChild(btn('Clear', function () { logs = []; badge.textContent = '🐞'; draw(); }));
    head.appendChild(btn('Close', function () { panel.style.display = 'none'; }));
    list = document.createElement('div');
    list.style.cssText = 'flex:1;overflow:auto;padding:6px 8px';
    panel.appendChild(head);
    panel.appendChild(list);
    badge.addEventListener('click', function () {
      var open = panel.style.display !== 'none';
      panel.style.display = open ? 'none' : 'flex';
      if (!open) draw();
    });
    document.body.appendChild(panel);
    document.body.appendChild(badge);
    var n = errCount();
    if (n) badge.textContent = '🐞 ' + n;
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build);
  else build();
})();
