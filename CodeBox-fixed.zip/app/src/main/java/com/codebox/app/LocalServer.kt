package com.codebox.app

import java.io.File
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * Tiny loopback-only HTTP server so previews run on http://127.0.0.1:<port>/ like in Spck
 * (ES modules, fetch(), localStorage all work). HTML pages get [inject] added at the top of <head>.
 * If [runnerHtml] is given it is served as /__run__.html (used to run plain .js files).
 */
class LocalServer(
    private val root: File,
    private val inject: String,
    private val runnerHtml: String?,
    private val phoneHtml: String? = null
) {
    private val rootPath = root.canonicalPath
    private val ss = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
    private val pool = Executors.newCachedThreadPool()

    @Volatile
    private var running = true

    val port: Int get() = ss.localPort

    fun start() {
        thread(isDaemon = true) {
            while (running) {
                try {
                    val s = ss.accept()
                    pool.execute { handle(s) }
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }
    }

    fun stop() {
        running = false
        try { ss.close() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    private fun handle(sock: Socket) {
        try {
            sock.use { s ->
                s.soTimeout = 10_000
                val input = s.getInputStream().bufferedReader(Charsets.ISO_8859_1)
                val line = input.readLine() ?: return
                while (true) {
                    val h = input.readLine()
                    if (h == null || h.isEmpty()) break
                }
                val parts = line.split(" ")
                if (parts.size < 2) return
                val method = parts[0]
                val out = s.getOutputStream()
                if (method != "GET" && method != "HEAD") {
                    send(out, 405, "text/plain", "Method not allowed".toByteArray(), false)
                    return
                }
                val head = method == "HEAD"
                val raw = parts[1].substringBefore('?').substringBefore('#')
                val path = URLDecoder.decode(raw.replace("+", "%2B"), "UTF-8")

                if (path == "/__run__.html" && runnerHtml != null) {
                    send(out, 200, "text/html; charset=utf-8", withInject(runnerHtml).toByteArray(), head)
                    return
                }

                if (path == "/__phone__.html" && phoneHtml != null) {
                    send(out, 200, "text/html; charset=utf-8", phoneHtml.toByteArray(), head)
                    return
                }

                var f = File(root, path.trimStart('/')).canonicalFile
                if (f.path != rootPath && !f.path.startsWith(rootPath + File.separator)) {
                    send(out, 403, "text/plain", "Forbidden".toByteArray(), head)
                    return
                }
                if (f.isDirectory) f = File(f, "index.html")
                if (!f.isFile) {
                    send(out, 404, "text/plain", "404 Not found: $path".toByteArray(), head)
                    return
                }
                val ext = f.extension.lowercase()
                val body = if (ext == "html" || ext == "htm") {
                    withInject(f.readText(Charsets.UTF_8)).toByteArray(Charsets.UTF_8)
                } else {
                    f.readBytes()
                }
                send(out, 200, mime(ext), body, head)
            }
        } catch (_: Exception) {
        }
    }

    private fun withInject(html: String): String {
        val tag = "<script>$inject</script>"
        val head = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(html)
        if (head != null) return html.substring(0, head.range.last + 1) + tag + html.substring(head.range.last + 1)
        val htmlTag = Regex("<html[^>]*>", RegexOption.IGNORE_CASE).find(html)
        if (htmlTag != null) return html.substring(0, htmlTag.range.last + 1) + tag + html.substring(htmlTag.range.last + 1)
        return tag + html
    }

    private fun send(out: OutputStream, code: Int, type: String, body: ByteArray, headOnly: Boolean) {
        val msg = when (code) {
            200 -> "OK"
            403 -> "Forbidden"
            404 -> "Not Found"
            else -> "Error"
        }
        val header = "HTTP/1.1 $code $msg\r\n" +
            "Content-Type: $type\r\n" +
            "Content-Length: ${body.size}\r\n" +
            "Cache-Control: no-store\r\n" +
            "Access-Control-Allow-Origin: *\r\n" +
            "Connection: close\r\n\r\n"
        out.write(header.toByteArray(Charsets.ISO_8859_1))
        if (!headOnly) out.write(body)
        out.flush()
    }

    private fun mime(ext: String): String = when (ext) {
        "html", "htm" -> "text/html; charset=utf-8"
        "js", "mjs" -> "application/javascript; charset=utf-8"
        "css" -> "text/css; charset=utf-8"
        "json", "map" -> "application/json; charset=utf-8"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "ico" -> "image/x-icon"
        "woff" -> "font/woff"
        "woff2" -> "font/woff2"
        "ttf" -> "font/ttf"
        "otf" -> "font/otf"
        "mp3" -> "audio/mpeg"
        "wav" -> "audio/wav"
        "ogg" -> "audio/ogg"
        "mp4" -> "video/mp4"
        "webm" -> "video/webm"
        "wasm" -> "application/wasm"
        "txt", "md", "kt", "java", "xml" -> "text/plain; charset=utf-8"
        else -> "application/octet-stream"
    }
}
