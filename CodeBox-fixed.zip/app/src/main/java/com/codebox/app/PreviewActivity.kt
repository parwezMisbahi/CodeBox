package com.codebox.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/**
 * Runs the user's HTML / JS file in a WebView through a local http server (no access to the app bridge).
 * devtools.js is injected into every page: on-screen dev log (errors, console, native calls)
 * plus a mock of the app's native bridge objects, so Kotlin-backed UIs still render.
 */
class PreviewActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var server: LocalServer? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("path")
        if (path == null) {
            finish()
            return
        }
        val file = File(path)
        // Serve the whole project folder (…/projects/<project>/) so relative paths, modules and fetch() work.
        var dir: File? = file.parentFile
        while (dir != null && dir.parentFile?.name != "projects") dir = dir.parentFile
        val root = dir ?: file.parentFile!!
        val rel = file.relativeTo(root).path.replace(File.separatorChar, '/')

        // Names of the app's native bridge objects (e.g. ["Android"]) that devtools.js fakes in the preview.
        var mocks = intent.getStringExtra("mocks") ?: "[]"
        if (!Regex("""\[("[A-Za-z_][A-Za-z0-9_]*"(,"[A-Za-z_][A-Za-z0-9_]*")*)?]""").matches(mocks)) mocks = "[]"
        val inject = assets.open("devtools.js").bufferedReader().use { it.readText() }
            .replace("__MOCKS__", mocks)
        val isJs = file.extension.lowercase() == "js"
        val phone = intent.getBooleanExtra("phone", false) && !isJs
        val phoneHtml = if (phone) {
            assets.open("phone.html").bufferedReader().use { it.readText() }
                .replace("__APP_URL__", "/" + Uri.encode(rel, "/"))
                .replace("__APP_NAME__", android.text.Html.escapeHtml(root.name))
        } else null
        val srv = LocalServer(root, inject, if (isJs) jsRunnerHtml(Uri.encode(rel, "/")) else null, phoneHtml)
        srv.start()
        server = srv

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(v: WebView?, url: String?, msg: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@PreviewActivity)
                    .setMessage(msg)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(v: WebView?, url: String?, msg: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@PreviewActivity)
                    .setMessage(msg)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }
                    .show()
                return true
            }
        }

        val base = "http://127.0.0.1:${srv.port}"
        web.loadUrl(
            if (isJs) "$base/__run__.html"
            else if (phone) "$base/__phone__.html"
            else "$base/" + Uri.encode(rel, "/")
        )

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })
    }

    private fun jsRunnerHtml(srcPath: String): String = """
<!doctype html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<body style="background:#111;color:#9f9;font:14px monospace;padding:12px">
<pre id="o" style="white-space:pre-wrap"></pre>
<script>
const o = document.getElementById('o');
['log','info','warn','error'].forEach(k => {
  const orig = console[k];
  console[k] = (...a) => {
    o.textContent += a.map(x => typeof x === 'object' ? JSON.stringify(x) : String(x)).join(' ') + '\n';
    orig.apply(console, a);
  };
});
window.onerror = (m, s, l) => { o.textContent += 'ERROR: ' + m + ' (line ' + l + ')\n'; };
</script>
<script src="$srcPath"></script>
""".trimIndent()

    override fun onDestroy() {
        server?.stop()
        web.destroy()
        super.onDestroy()
    }
}
