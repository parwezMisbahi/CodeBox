package com.codebox.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    lateinit var web: WebView
    lateinit var store: ProjectStore
    var pendingExport: String? = null
    private var lastApk: File? = null
    private val building = AtomicBoolean(false)
    @Volatile private var foreground = false

    override fun onResume() {
        super.onResume()
        foreground = true
    }

    override fun onPause() {
        foreground = false
        super.onPause()
    }

    fun prefs(): SharedPreferences = getSharedPreferences("codebox", Context.MODE_PRIVATE)

    private val zipPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importZip(uri)
        }

    private val zipExporter =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            val project = pendingExport
            pendingExport = null
            if (uri != null && project != null) exportZip(project, uri)
        }

    var pendingImportDir: String? = null

    private val filesPicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val dir = pendingImportDir
            pendingImportDir = null
            if (dir != null && uris.isNotEmpty()) importFiles(dir, uris)
        }

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) importFolder(uri)
        }

    var pendingFolderExport: String? = null

    private val folderExporter =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            val project = pendingFolderExport
            pendingFolderExport = null
            if (uri != null && project != null) exportFolder(project, uri)
        }

    fun launchFolderExport(project: String) {
        pendingFolderExport = project
        folderExporter.launch(null)
    }

    private fun exportFolder(project: String, uri: Uri) {
        thread {
            try {
                val tree = DocumentFile.fromTreeUri(this, uri)
                    ?: throw IllegalStateException("Folder khul nahi saka")
                val n = store.copyToTree(contentResolver, project, tree)
                emit("folderExported", "$project ($n files)")
            } catch (t: Throwable) {
                emit("error", "Folder export fail: " + (t.message ?: t.toString()))
            }
        }
    }

    /** Zip of the project (without build junk) handed to any app via the share sheet. */
    fun shareZip(project: String) {
        val dir = File(cacheDir, "share").apply { mkdirs() }
        val zip = File(dir, "$project.zip")
        zip.outputStream().use { store.zipProject(project, it, forBuild = true) }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", zip)
        val send = Intent(Intent.ACTION_SEND)
            .setType("application/zip")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, "Project zip bhejo").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Opens AndroidIDE if it is installed. */
    fun openIde(): Boolean {
        val i = packageManager.getLaunchIntentForPackage("com.itsaky.androidide") ?: return false
        startActivity(i)
        return true
    }

    fun launchFilesPicker(dirRel: String) {
        pendingImportDir = dirRel
        filesPicker.launch(arrayOf("*/*"))
    }

    fun launchFolderPicker() {
        folderPicker.launch(null)
    }

    fun launchZipPicker() {
        zipPicker.launch(
            arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
        )
    }

    fun launchZipExport(project: String) {
        zipExporter.launch("$project.zip")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStore(filesDir)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage?): Boolean = true
        }
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.handleBack ? window.handleBack() : false)") { r ->
                    if (r != "true") finish()
                }
            }
        })
    }

    fun emit(type: String, payload: String) {
        val js = "window.onNative && window.onNative(${JSONObject.quote(type)}, ${JSONObject.quote(payload)})"
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    private fun rawName(uri: Uri, fallback: String): String {
        var name = fallback
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
        }
        return name
    }

    private fun displayName(uri: Uri): String =
        rawName(uri, "project").removeSuffix(".zip").removeSuffix(".ZIP")

    private fun importFiles(dirRel: String, uris: List<Uri>) {
        thread {
            try {
                var n = 0
                uris.forEach { u ->
                    store.importFile(contentResolver, u, dirRel, rawName(u, "file"))
                    n++
                }
                emit("filesImported", JSONObject().put("dir", dirRel).put("count", n).toString())
            } catch (t: Throwable) {
                emit("error", "Import fail: " + (t.message ?: t.toString()))
            }
        }
    }

    private fun importFolder(uri: Uri) {
        thread {
            try {
                val tree = DocumentFile.fromTreeUri(this, uri)
                    ?: throw IllegalStateException("Folder khul nahi saka")
                val name = store.importTree(contentResolver, tree)
                emit("imported", name)
            } catch (t: Throwable) {
                emit("error", "Import fail: " + (t.message ?: t.toString()))
            }
        }
    }

    private fun importZip(uri: Uri) {
        val base = displayName(uri)
        thread {
            try {
                val input = contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("Zip khul nahi saki")
                val name = store.unzip(input, base)
                emit("imported", name)
            } catch (t: Throwable) {
                emit("error", "Import fail: " + (t.message ?: t.toString()))
            }
        }
    }

    private fun exportZip(project: String, uri: Uri) {
        thread {
            try {
                val out = contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("Save location nahi khuli")
                store.zipProject(project, out)
                emit("exported", project)
            } catch (t: Throwable) {
                emit("error", "Export fail: " + (t.message ?: t.toString()))
            }
        }
    }

    /* ---------- cloud build (GitHub Actions) ---------- */

    private fun buildEvent(stage: String, vararg extra: Pair<String, String>) {
        val o = JSONObject().put("stage", stage)
        extra.forEach { o.put(it.first, it.second) }
        emit("build", o.toString())
    }

    fun startBuild(project: String) {
        val token = prefs().getString("gh_token", null)
        if (token.isNullOrEmpty()) throw IllegalStateException("GitHub token set nahi hai")
        if (!building.compareAndSet(false, true)) throw IllegalStateException("Build pehle se chal raha hai")
        thread {
            try {
                buildEvent("progress", "msg" to "Project zip ban rahi hai...")
                val zip = File(cacheDir, "project.zip")
                zip.outputStream().use { store.zipProject(project, it, forBuild = true) }
                val workflow = assets.open("cloud-build.yml").use { it.readBytes() }
                val builder = CloudBuild(token, cacheDir, workflow) { m ->
                    buildEvent("progress", "msg" to m)
                }
                val res = builder.run(zip, project)
                zip.delete()
                val apk = res.apk
                if (apk != null) {
                    lastApk = apk
                    buildEvent("done", "name" to apk.name)
                    // If the user is still in the app, open the installer right away.
                    if (foreground) runOnUiThread { installApk() }
                } else {
                    buildEvent("fail", "msg" to res.message, "log" to res.log)
                }
            } catch (t: Throwable) {
                buildEvent("fail", "msg" to (t.message ?: t.toString()), "log" to "")
            } finally {
                building.set(false)
            }
        }
    }

    fun installApk() {
        val apk = lastApk
        if (apk == null || !apk.exists()) {
            emit("error", "Pehle build karo, APK nahi mili")
            return
        }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            emit("error", "CodeBox ko install allow karo, phir Install dobara dabao")
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
        startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
